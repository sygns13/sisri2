export default {
  methods: {
    redirect (response) {
      window.location.reload()
    }
  }
}
