<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detalledocente extends Model
{
    //
}
