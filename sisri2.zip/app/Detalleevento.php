<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Detalleevento extends Model
{
    //
}
