<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Adminlocacion extends Model
{
    //
}
