<?php

namespace App\Http\Controllers;

use App\Detalleinvestigacion;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class DetalleinvestigacionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Detalleinvestigacion  $detalleinvestigacion
     * @return \Illuminate\Http\Response
     */
    public function show(Detalleinvestigacion $detalleinvestigacion)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Detalleinvestigacion  $detalleinvestigacion
     * @return \Illuminate\Http\Response
     */
    public function edit(Detalleinvestigacion $detalleinvestigacion)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Detalleinvestigacion  $detalleinvestigacion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Detalleinvestigacion $detalleinvestigacion)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Detalleinvestigacion  $detalleinvestigacion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Detalleinvestigacion $detalleinvestigacion)
    {
        //
    }
}
